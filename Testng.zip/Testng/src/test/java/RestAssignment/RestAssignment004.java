package RestAssignment;


import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class RestAssignment004 {
    private static final String BASE_URL = "https://petstore.swagger.io/#/";
    private static final String USERNAME = "Uname001";
    private static final String PASSWORD = "@ttitude";

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void loginUser() {
        given()
                .queryParam("username", USERNAME)
                .queryParam("password", PASSWORD)
                .when()
                .get("/user/loginUser")
                .then()
                .statusCode(200)
                .body("username", equalTo(USERNAME))
                .body("email", equalTo("Positive@Attitude.com"))
                .body("userStatus", equalTo(1));
    }
}

