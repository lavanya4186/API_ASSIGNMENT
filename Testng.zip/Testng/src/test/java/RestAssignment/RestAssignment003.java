package RestAssignment;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

    public class RestAssignment003 {
        private static final String BASE_URL = "https://petstore.swagger.io/v2";
        private static final String USERNAME = "Uname001";

        @BeforeClass
        public void setup() {
            RestAssured.baseURI = BASE_URL;
        }

        @Test
        public void getUserDetails() {
            given()
                    .pathParam("username", USERNAME)
                    .when()
                    .get("/user/{username}")
                    .then()
                    .statusCode(200)
                    .body("username", equalTo(USERNAME))
                    .body("email", equalTo("Positive@Attitude.com"))
                    .body("userStatus", equalTo(1));
        }
    }


