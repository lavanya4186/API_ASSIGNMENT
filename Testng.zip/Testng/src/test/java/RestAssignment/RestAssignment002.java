package RestAssignment;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

public class RestAssignment002 {
    private static final String BASE_URL = "https://petstore.swagger.io/v2";
    private Map<String, String> environmentStatusMap;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
        initializeEnvironmentStatusMap();
    }

    private void initializeEnvironmentStatusMap() {
        environmentStatusMap = new HashMap<>();
        environmentStatusMap.put("DEV", "available_DEV");
        environmentStatusMap.put("QA", "available_QA");
        environmentStatusMap.put("PROD", "available_PROD");
    }

    @DataProvider(name = "environments")
    public Object[][] environmentData() {
        return new Object[][]{
                {"DEV"},
                {"QA"},
                {"PROD"}
        };
    }

    @Test(priority = 1, dataProvider = "environments")
    public void putCallTesting(String environment) {
        String status = environmentStatusMap.get(environment);

        String requestBody = "{\n" +
                "  \"id\": 9223372016900013000,\n" +
                "  \"category\": {\n" +
                "    \"id\": 20021,\n" +
                "    \"name\": \"string\"\n" +
                "  },\n" +
                "  \"name\": \"Doggie\",\n" +
                "  \"photoUrls\": [\n" +
                "    \"string\"\n" +
                "  ],\n" +
                "  \"tags\": [\n" +
                "    {\n" +
                "      \"id\": 0,\n" +
                "      \"name\": \"string\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"status\": \"" + status + "\"\n" +
                "}";

        Response response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .put("/pet");

        Assert.assertEquals(response.getStatusCode(), 200);

        int id = response.jsonPath().getInt("id");
        Assert.assertEquals(id, 20021);
    }
}
