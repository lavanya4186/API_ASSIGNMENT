package RestAssignment;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class RestAssignment005 {
    private static final String BASE_URL = "http://petstore.swagger.io/v2";
    private static final String STATUS_AVAILABLE = "available";
    private static final String STATUS_PENDING = "pending";
    private static final String STATUS_SOLD = "sold";

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test
    public void findByStatusAvailable() {
        given()
                .queryParam("status", STATUS_AVAILABLE)
                .when()
                .get("/pet/findByStatus")
                .then()
                .statusCode(200)
                .body("status", everyItem(equalTo(STATUS_AVAILABLE)));
    }

    @Test
    public void findByStatusPending() {
        given()
                .queryParam("status", STATUS_PENDING)
                .when()
                .get("/pet/findByStatus")
                .then()
                .statusCode(200)
                .body("status", everyItem(equalTo(STATUS_PENDING)));
    }

    @Test
    public void findByStatusSold() {
        given()
                .queryParam("status", STATUS_SOLD)
                .when()
                .get("/pet/findByStatus")
                .then()
                .statusCode(200)
                .body("status", everyItem(equalTo(STATUS_SOLD)));
    }
}

