package RestAssignment;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

public class RestAssignment001 {
    private static final String BASE_URL = "http://petstore.swagger.io/v2";
    private int petId;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test(priority = 1)
    public void createPet() {
        String requestBody = "{\n" +
                "  \"id\": 344,\n" +
                "  \"category\": {\n" +
                "    \"id\": 0,\n" +
                "    \"name\": \"string\"\n" +
                "  },\n" +
                "  \"name\": \"Doggie\",\n" +
                "  \"photoUrls\": [\n" +
                "    \"string\"\n" +
                "  ],\n" +
                "  \"tags\": [\n" +
                "    {\n" +
                "      \"id\": 0,\n" +
                "      \"name\": \"string\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"status\": \"available\"\n" +
                "}";

        Response response = given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post("/pet");

        Assert.assertEquals(response.getStatusCode(), 200);

        petId = response.jsonPath().getInt("id");
    }

    @Test(priority = 2, dependsOnMethods = "createPet")
    public void getPet() {
        Response response = given()
                .contentType("application/json")
                .when()
                .get("/pet/{petId}", petId);

        Assert.assertEquals(response.getStatusCode(), 200);

        String status = response.jsonPath().getString("status");
        Assert.assertEquals(status, "available");
    }

    @Test(priority = 3, dependsOnMethods = "getPet")
    public void deletePet() {
        Response response = given()
                .contentType("application/json")
                .when()
                .delete("/pet/{petId}", petId);

        Assert.assertEquals(response.getStatusCode(), 200);

        String code = response.jsonPath().getString("code");
        String message = response.jsonPath().getString("message");

        Assert.assertEquals(code, "200");
        Assert.assertEquals(message, String.valueOf(petId));
    }
}
